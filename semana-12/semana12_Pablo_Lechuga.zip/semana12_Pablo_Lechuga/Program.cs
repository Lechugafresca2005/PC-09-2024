﻿namespace semana12_Pablo_Lechuga
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese dos números");
           int a = Convert.ToInt32(Console.ReadLine());
          int b = Convert.ToInt32(Console.ReadLine());
           Console.WriteLine("Desea sumar o restar los 2 números ");
            menu( a, b);
        }
 
        static void menu(int a, int b)
        {
            Console.WriteLine("Semana 12");
             Console.WriteLine(" a) Multiplicación");
            Console.WriteLine(" b) Suma");
            Console.WriteLine(" c) Resta");
 
            char opcion = Console.ReadLine().ToLower()[0];
            switch (opcion)
            {
                case 'a':
                    Console.WriteLine("El resultado es :" + Multiplicacion (a,  b));
                    break;
                case 'b':
                    Console.WriteLine("El resultado es :" + Suma (a,  b));
                    Console.ReadKey();
                    
                    break;
                      case 'c':
                    Console.WriteLine("El resultado es :" + Resta(a, b));
                     break;
                     
                default:
                    Console.WriteLine("La opción seleccionada no es válida.");
                    break;
            }
        }
 
        //envio de parámetros
        public static int Suma (int a, int b)
        {
            return a + b;
        }

        public static int Resta (int a, int b)
        {
            return a - b;
        }
        public static int Multiplicacion(int a, int b)
        {
            return a * b;
        }
 
    }
}