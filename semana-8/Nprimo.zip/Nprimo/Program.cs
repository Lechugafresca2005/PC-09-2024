﻿using System;

namespace Nprimo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("favor colocar el número a analizar y que no sea mayor de 6 cifras:");
            int numero;
            if (int.TryParse(Console.ReadLine(), out numero))
            {
                if (numero > 0 && numero <= 1000000)
                {
                    bool esPrimo = true;
                    for (int divisor = 2; divisor <= numero / 2; divisor++)
                    {
                        if (numero % divisor == 0)
                        {
                            esPrimo = false;
                            break;
                        }
                    }

                    if (esPrimo)
                    {
                        Console.WriteLine($"{numero} es primo.");
                    }
                    else
                    {
                        Console.WriteLine($"{numero} no es primo.");
                    }
                }
                else
                {
                    Console.WriteLine("el numero es mayor a 6 cifras.");
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Por favor ingrese un número entero positivo.");
            }
        }
    }
}
