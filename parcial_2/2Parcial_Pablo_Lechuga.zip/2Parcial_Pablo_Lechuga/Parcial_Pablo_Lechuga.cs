﻿
class Parcial_Pablo_Lechuga

{
    static void Main()
    {
        string[] nombres = new string[10];
        int[] notas = new int[10];

        for (int i = 0; i < 10; i++)
        {
            Console.Write("Ingrese el nombre del alumno {0}: ", i + 1);
            nombres[i] = Console.ReadLine();

            bool ingresoValido = false;
            do
            {
                Console.Write("Ingrese la nota del alumno {0}: ", i + 1);
                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out int nota))
                {
                    if (nota >= 0 && nota <= 100)
                    {
                        notas[i] = nota;
                        ingresoValido = true;
                    }
                    else
                    {
                        Console.WriteLine("La nota debe de estar etre 0 y 100");
                    }
                }
                else
                {
                    Console.WriteLine("ingrese un número entero, intente de nuevo");
                }
            } while (!ingresoValido);
        }

        bool salir = false;
        do
        {
            Console.WriteLine("\nMENU:");
            Console.WriteLine("1) Mostrar nombre y nota de alumnos que aprobaron el curso.");
            Console.WriteLine("2) Mostrar nombre y nota de alumnos que no aprobaron el curso.");
            Console.WriteLine("3) Mostrar el promedio de notas del grupo.");
            Console.WriteLine("4) Salir del programa.");
            Console.Write("Seleccione una opción: ");

            if (int.TryParse(Console.ReadLine(), out int opcion))
            {
                switch (opcion)
                {
                    case 1:
                        MostrarAprobados(nombres, notas);
                        break;
                    case 2:
                        MostrarNoAprobados(nombres, notas);
                        break;
                    case 3:
                        MostrarPromedio(notas);
                        break;
                    case 4:
                        salir = true;
                        break;
                    default:
                        Console.WriteLine("Opción no valida, intente de nuevo.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("ingrse un número que sea entero, intelo de nuevo.");
            }
        } while (!salir);
    }

    static void MostrarAprobados(string[] nombres, int[] notas)
    {
        Console.WriteLine("\nAlumnos aprobados:");
        for (int i = 0; i < nombres.Length; i++)
        {
            if (notas[i] >= 65)
            {
                Console.WriteLine("{0}: {1}", nombres[i], notas[i]);
            }
        }
    }

    static void MostrarNoAprobados(string[] nombres, int[] notas)
    {
        Console.WriteLine("\nAlumnos reprobados:");
        for (int i = 0; i < nombres.Length; i++)
        {
            if (notas[i] < 65)
            {
                Console.WriteLine("{0}: {1}", nombres[i], notas[i]);
            }
        }
    }

static void MostrarPromedio(int[] notas)
{
    double promedio = 0;
    foreach (int nota in notas)
    {
        promedio += nota;
    }
    promedio /= notas.Length;
    Console.WriteLine("\nEl promedio de notas del grupo es: {0}", promedio);
}

}

